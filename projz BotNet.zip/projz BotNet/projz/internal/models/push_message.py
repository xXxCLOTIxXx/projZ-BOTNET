from dataclasses import dataclass


@dataclass
class Pagination:
    body: str
    deep_link: str
